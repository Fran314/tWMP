package com.example.myapp003.ui.meals;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.example.myapp003.DayAndMeals;
import com.example.myapp003.EditMealsDialog;
import com.example.myapp003.R;

public class MealsFragment extends Fragment {

    private MealsViewModel mealsViewModel;

    private DayAndMeals[] days = new DayAndMeals[7];
    private ImageButton[] mButtonEdit = new ImageButton[7];
    private ImageButton mButtonShopList;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        mealsViewModel =
                ViewModelProviders.of(this).get(MealsViewModel.class);
        View root = inflater.inflate(R.layout.fragment_meals, container, false);


        days[0] = root.findViewById(R.id.monday);
        days[1] = root.findViewById(R.id.tuesday);
        days[2] = root.findViewById(R.id.wednesday);
        days[3] = root.findViewById(R.id.thursday);
        days[4] = root.findViewById(R.id.friday);
        days[5] = root.findViewById(R.id.saturday);
        days[6] = root.findViewById(R.id.sunday);

        mButtonEdit[0] = days[0].findViewById(R.id.button_edit_day);
        mButtonEdit[1] = days[1].findViewById(R.id.button_edit_day);
        mButtonEdit[2] = days[2].findViewById(R.id.button_edit_day);
        mButtonEdit[3] = days[3].findViewById(R.id.button_edit_day);
        mButtonEdit[4] = days[4].findViewById(R.id.button_edit_day);
        mButtonEdit[5] = days[5].findViewById(R.id.button_edit_day);
        mButtonEdit[6] = days[6].findViewById(R.id.button_edit_day);

        mButtonEdit[0].setOnClickListener
                (
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                EditMealsDialog d = new EditMealsDialog(getContext());
                                d.setContentView(R.layout.edit_dialog_layout);

                                TextView mTextDay = d.findViewById(R.id.text_day_name);
                                mTextDay.setText(getResources().getString(R.string.meals_monday));

                                d.show();
                            }
                        }
                );
        mButtonEdit[1].setOnClickListener
                (
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                EditMealsDialog d = new EditMealsDialog(getContext());
                                d.setContentView(R.layout.edit_dialog_layout);

                                TextView mTextDay = d.findViewById(R.id.text_day_name);
                                mTextDay.setText(getResources().getString(R.string.meals_tuesday));

                                d.show();
                            }
                        }
                );
        mButtonEdit[2].setOnClickListener
                (
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                EditMealsDialog d = new EditMealsDialog(getContext());
                                d.setContentView(R.layout.edit_dialog_layout);

                                TextView mTextDay = d.findViewById(R.id.text_day_name);
                                mTextDay.setText(getResources().getString(R.string.meals_wednesday));

                                d.show();
                            }
                        }
                );
        mButtonEdit[3].setOnClickListener
                (
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                EditMealsDialog d = new EditMealsDialog(getContext());
                                d.setContentView(R.layout.edit_dialog_layout);

                                TextView mTextDay = d.findViewById(R.id.text_day_name);
                                mTextDay.setText(getResources().getString(R.string.meals_thursday));

                                d.show();
                            }
                        }
                );
        mButtonEdit[4].setOnClickListener
                (
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                EditMealsDialog d = new EditMealsDialog(getContext());
                                d.setContentView(R.layout.edit_dialog_layout);

                                TextView mTextDay = d.findViewById(R.id.text_day_name);
                                mTextDay.setText(getResources().getString(R.string.meals_friday));

                                d.show();
                            }
                        }
                );
        mButtonEdit[5].setOnClickListener
                (
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                EditMealsDialog d = new EditMealsDialog(getContext());
                                d.setContentView(R.layout.edit_dialog_layout);

                                TextView mTextDay = d.findViewById(R.id.text_day_name);
                                mTextDay.setText(getResources().getString(R.string.meals_saturday));

                                d.show();
                            }
                        }
                );
        mButtonEdit[6].setOnClickListener
                (
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                EditMealsDialog d = new EditMealsDialog(getContext());
                                d.setContentView(R.layout.edit_dialog_layout);

                                TextView mTextDay = d.findViewById(R.id.text_day_name);
                                mTextDay.setText(getResources().getString(R.string.meals_sunday));

                                d.show();
                            }
                        }
                );

        mButtonShopList = root.findViewById(R.id.button_shopping_list);
        mButtonShopList.setOnClickListener
                (
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                AlertDialog.Builder builder=new AlertDialog.Builder(getContext());
                                builder.setTitle("Work In Progress!");
                                builder.setMessage("Per adesso non è possibile ottenere la lista\n" +
                                        "della spesa. In futuro, invece, sarà possibile.");
                                builder.show();
                            }
                        }
                );

        return root;
    }
}